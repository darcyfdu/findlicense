# -*- coding: UTF-8 -*-
import sqlite3
from flask import Flask, request, session, g, redirect, url_for, \
     abort, render_template, flash
from flask import make_response
from contextlib import closing
import requests
import urllib
import random
import os
import sys
import time
requests_session = requests.session() 
basedir = os.path.abspath(os.path.dirname(__file__))
# create our little application :)
app = Flask(__name__)
app.config.from_object(__name__)
app.secret_key = '123456'
@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/test', methods=['GET', 'POST'])
def test():
    if(request.form['giturl']):
        url = request.form['giturl']
        filename = url.rsplit('/')[-1].rsplit('.')[0]
        session['filename'] = filename
        cm = 'git clone '+request.form['giturl']+' templates/'+filename
        os.popen(cm)
        if(os.path.exists('templates/'+filename)):
            return redirect('/add')
        else:
            return '仓库git下载失败，请重试！'
    elif(request.files['file1']):
        file_dir=os.path.join(basedir,'templates')
        f=request.files['file1']
        filename = f.filename.lower()
        session['filename'] = filename.rsplit('.', 1)[0]
        f.save(os.path.join(file_dir,filename))
        if '.zip' in filename:
            cm = 'unzip -n '+file_dir+'/'+filename+' -d templates'
            os.popen(cm)
            cm = 'rm -f '+file_dir+'/'+filename
            os.popen(cm)
        if '.tar.gz' in filename:
            cm = 'tar -zxvf '+file_dir+'/'+filename+' -C templates'
            os.popen(cm)
            cm = 'rm -f '+file_dir+'/'+filename
            os.popen(cm)
        if '.tar.bz2' in filename:
            cm = 'tar -jcvf '+file_dir+'/'+filename+' -C templates'
            os.popen(cm)
            cm = 'rm -f '+file_dir+'/'+filename
            os.popen(cm)
        if(os.path.exists('templates/'+session['filename'])):
            return redirect('/add')
        else:
            return '文件上传解压缩失败，请重试！'
    return '请重试！'
@app.route('/add', methods=['GET','POST'])
def add():
    name = session['filename']
    ISOTIMEFORMAT='-%Y-%m-%d-%X'
    scantime = time.strftime(ISOTIMEFORMAT,time.localtime())
    cm = './scancode -cl  -n 8 --format html templates/'+name+' templates/'+name+scantime+'.html'
    val = os.popen(cm).read()
    cm = 'rm -rf templates/'+name
    os.popen(cm)
    return render_template(name+scantime+'.html')
@app.route('/src/licensedcode/data/licenses/<path>', methods=['GET','POST'])
def today(path):
    base_dir = os.path.dirname(__file__)+'src/licensedcode/data/licenses/'
    resp = open(os.path.join(base_dir, path)).read()#.replace('\n','<br />')
    #resp.headers["Content-type"]="text/html;charset=UTF-8"
    #return resp
    return render_template('licenses.html',data=resp)
if __name__ == '__main__':
    if sys.getdefaultencoding() != 'utf8': 
        reload(sys)
        sys.setdefaultencoding('utf8')
    app.run(host='0.0.0.0',debug=True,threaded = True)


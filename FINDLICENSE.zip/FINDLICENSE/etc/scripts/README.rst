This directory contains miscellaneous scripts of some use with ScanCode.

    - json2csv: convert a scan JSON to a CSV.
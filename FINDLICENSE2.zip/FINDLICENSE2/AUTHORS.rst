The following organizations or individuals have contributed to ScanCode:

- Chin-Yeung Li @chinyeungli
- Jillian Daguil @jdaguil
- Li Ha @linexb
- nexB Inc. @nexB
- Philippe Ombredanne @pombredanne
- Sebastian Roth @ened
- Steven Esser @majurg
- Sebastian Schuberth @sschuberth
- Rakesh Balusa @balusarakesh
- Francois Granade @farialima
- Savino Sguera @savinos

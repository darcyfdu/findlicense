# scancode-thirdparty
Thirdparty dependencies repository

See .ABOUT files for provenance details

